import React, { useState, useEffect } from 'react';
import AboutPage from './pages/AboutPage';

function App() {
  const [currentPath, setCurrentPath] = useState(window.location.pathname);

  useEffect(() => {
    const handleLocationChange = () => {
      setCurrentPath(window.location.pathname);
    };

    window.addEventListener('popstate', handleLocationChange);
    return () => window.removeEventListener('popstate', handleLocationChange);
  }, []);

  // Simple router
  const renderPage = () => {
    switch (currentPath) {
      case '/about':
        return <AboutPage />;
      default:
        return (
          <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center p-4">
            <div className="bg-white p-8 rounded-lg shadow-md max-w-md w-full text-center">
              <h1 className="text-2xl font-bold text-blue-900 mb-4">Welcome to Esamoti HDF</h1>
              <p className="text-gray-700 mb-6">
                We provide microfinance solutions to help eliminate poverty and create a peaceful society.
              </p>
              <button 
                onClick={() => {
                  window.history.pushState({}, '', '/about');
                  setCurrentPath('/about');
                }}
                className="bg-blue-600 text-white font-semibold py-2 px-6 rounded-full hover:bg-blue-700 transition-colors"
              >
                About Us
              </button>
            </div>
          </div>
        );
    }
  };

  return renderPage();
}

export default App;