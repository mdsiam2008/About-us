import React from 'react';
import { Phone, Mail, MapPin, Clock } from 'lucide-react';
import { Link } from './Link';

const Footer: React.FC = () => {
  return (
    <footer className="bg-blue-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">Esamoti HDF</h3>
            <p className="text-blue-100 mb-4">
              Building a better future through financial empowerment since 2006.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-blue-100 hover:text-white transition-colors">Home</Link>
              </li>
              <li>
                <Link to="/about" className="text-blue-100 hover:text-white transition-colors">About Us</Link>
              </li>
              <li>
                <Link to="/services" className="text-blue-100 hover:text-white transition-colors">Services</Link>
              </li>
              <li>
                <Link to="/contact" className="text-blue-100 hover:text-white transition-colors">Contact</Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Our Services</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/services" className="text-blue-100 hover:text-white transition-colors">Small Loans</Link>
              </li>
              <li>
                <Link to="/services" className="text-blue-100 hover:text-white transition-colors">Medium Loans</Link>
              </li>
              <li>
                <Link to="/services" className="text-blue-100 hover:text-white transition-colors">Financial Advice</Link>
              </li>
              <li>
                <Link to="/services" className="text-blue-100 hover:text-white transition-colors">Business Support</Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <MapPin size={18} className="mr-2 mt-1 flex-shrink-0" />
                <span className="text-blue-100">4/3, Baskshipara Lane, Khulna, Bangladesh</span>
              </li>
              <li className="flex items-start">
                <Phone size={18} className="mr-2 mt-1 flex-shrink-0" />
                <div className="text-blue-100">
                  <div>+880 1912189608</div>
                  <div>+880 1763009300</div>
                </div>
              </li>
              <li className="flex items-center">
                <Mail size={18} className="mr-2 flex-shrink-0" />
                <span className="text-blue-100">esamotihdf@gmail.com</span>
              </li>
              <li className="flex items-start mt-4">
                <Clock size={18} className="mr-2 mt-1 flex-shrink-0" />
                <div className="text-blue-100">
                  <div className="font-semibold">Working Hours:</div>
                  <div>Saturday to Thursday: 10:00 AM - 5:00 PM</div>
                  <div>Friday: Closed</div>
                </div>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-blue-800 mt-8 pt-8 text-center">
          <p className="text-blue-200">
            &copy; {new Date().getFullYear()} Esamoti HDF. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;