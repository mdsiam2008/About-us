import React from 'react';
import { Users, Target, Banknote, Calendar, Award } from 'lucide-react';

const AboutUs: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      {/* Hero Section */}
      <div className="bg-blue-900 text-white">
        <div className="container mx-auto px-4 py-16 md:py-24">
          <h1 className="text-3xl md:text-5xl font-bold mb-6 animate-fade-in">About Us</h1>
          <p className="text-xl md:text-2xl max-w-3xl opacity-90">
            Building a better future through financial empowerment since 2006
          </p>
        </div>
      </div>
      
      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        {/* Our History */}
        <section className="mb-16">
          <div className="flex flex-col md:flex-row items-start gap-8">
            <div className="md:w-1/2 animate-slide-in-left">
              <h2 className="text-2xl md:text-3xl font-bold text-blue-900 mb-6 flex items-center">
                <Users className="mr-3 text-blue-600" />
                Our History
              </h2>
              <div className="bg-white rounded-lg shadow-md p-6 md:p-8 border-l-4 border-blue-600">
                <p className="text-gray-700 mb-4">
                  Established in 2006 by <span className="font-semibold">Abul Kashem</span>, a former banker and freedom fighter in Bangladesh, our organization was founded with a vision to create meaningful change.
                </p>
                <p className="text-gray-700 mb-4">
                  With his experience in the banking sector and deep patriotic roots as a freedom fighter, Mr. Kashem understood the challenges faced by underserved communities and the transformative power of financial inclusion.
                </p>
                <p className="text-gray-700">
                  For over {new Date().getFullYear() - 2006} years, we have been dedicated to serving communities across Bangladesh, growing from a small initiative to an established institution making a significant impact.
                </p>
              </div>
            </div>
            <div className="md:w-1/2 animate-slide-in-right">
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="h-64 bg-blue-100 flex items-center justify-center">
                  <div className="text-center p-8">
                    <Award className="w-16 h-16 text-blue-600 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-blue-900">Founded in 2006</h3>
                    <p className="text-gray-600 mt-2">By Abul Kashem, Freedom Fighter</p>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-blue-900 mb-3">Our Journey</h3>
                  <div className="space-y-3">
                    <div className="flex items-start">
                      <div className="bg-blue-100 rounded-full p-1 mr-3 mt-1">
                        <div className="bg-blue-600 rounded-full w-3 h-3"></div>
                      </div>
                      <div>
                        <p className="font-medium">2006: Foundation</p>
                        <p className="text-sm text-gray-600">Established by Abul Kashem</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <div className="bg-blue-100 rounded-full p-1 mr-3 mt-1">
                        <div className="bg-blue-600 rounded-full w-3 h-3"></div>
                      </div>
                      <div>
                        <p className="font-medium">2010: Growth</p>
                        <p className="text-sm text-gray-600">Expanded services to multiple regions</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <div className="bg-blue-100 rounded-full p-1 mr-3 mt-1">
                        <div className="bg-blue-600 rounded-full w-3 h-3"></div>
                      </div>
                      <div>
                        <p className="font-medium">2015: Milestone</p>
                        <p className="text-sm text-gray-600">Served 10,000+ beneficiaries</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <div className="bg-blue-100 rounded-full p-1 mr-3 mt-1">
                        <div className="bg-blue-600 rounded-full w-3 h-3"></div>
                      </div>
                      <div>
                        <p className="font-medium">Today</p>
                        <p className="text-sm text-gray-600">Continuing our mission with enhanced services</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* Our Mission */}
        <section className="mb-16">
          <h2 className="text-2xl md:text-3xl font-bold text-blue-900 mb-6 flex items-center">
            <Target className="mr-3 text-blue-600" />
            Our Mission
          </h2>
          <div className="bg-white rounded-lg shadow-md p-8 border-l-4 border-green-600 animate-fade-in">
            <p className="text-gray-700 mb-6 text-lg">
              We are dedicated to eliminating poverty by providing financial opportunities to those who need them most. Our mission is to create a peaceful society that is illuminated with hope and prosperity.
            </p>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="bg-blue-50 p-6 rounded-lg transition-all duration-300 hover:shadow-md hover:-translate-y-1">
                <h3 className="font-bold text-blue-900 mb-2">Financial Inclusion</h3>
                <p className="text-gray-700">Providing access to financial services for underserved communities</p>
              </div>
              <div className="bg-blue-50 p-6 rounded-lg transition-all duration-300 hover:shadow-md hover:-translate-y-1">
                <h3 className="font-bold text-blue-900 mb-2">Poverty Reduction</h3>
                <p className="text-gray-700">Working to eliminate poverty through sustainable economic opportunities</p>
              </div>
              <div className="bg-blue-50 p-6 rounded-lg transition-all duration-300 hover:shadow-md hover:-translate-y-1">
                <h3 className="font-bold text-blue-900 mb-2">Social Development</h3>
                <p className="text-gray-700">Building peaceful communities through economic empowerment</p>
              </div>
            </div>
          </div>
        </section>
        
        {/* Our Services */}
        <section className="mb-16">
          <h2 className="text-2xl md:text-3xl font-bold text-blue-900 mb-6 flex items-center">
            <Banknote className="mr-3 text-blue-600" />
            Our Loan Services
          </h2>
          <div className="bg-white rounded-lg shadow-md overflow-hidden animate-slide-up">
            <div className="p-8">
              <p className="text-gray-700 mb-8">
                We provide accessible microfinance solutions designed to help individuals and small businesses thrive. Our loan programs are structured with favorable terms to ensure they serve as stepping stones to financial independence.
              </p>
              
              <div className="flex flex-col md:flex-row gap-6">
                <div className="flex-1 border rounded-lg overflow-hidden">
                  <div className="bg-blue-800 text-white p-4">
                    <h3 className="font-bold text-xl">Small Loans</h3>
                    <p className="opacity-80">For individuals & micro-businesses</p>
                  </div>
                  <div className="p-6">
                    <div className="flex justify-between mb-3 pb-3 border-b">
                      <span className="text-gray-600">Starting amount:</span>
                      <span className="font-semibold">10,000 BDT</span>
                    </div>
                    <div className="flex justify-between mb-3 pb-3 border-b">
                      <span className="text-gray-600">Maximum amount:</span>
                      <span className="font-semibold">50,000 BDT</span>
                    </div>
                    <div className="flex justify-between mb-3 pb-3 border-b">
                      <span className="text-gray-600">Term:</span>
                      <span className="font-semibold">1 year</span>
                    </div>
                    <div className="flex items-center justify-center mt-6">
                      <Calendar className="text-blue-600 mr-2" size={18} />
                      <span className="text-gray-700">Flexible repayment options</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex-1 border rounded-lg overflow-hidden">
                  <div className="bg-blue-700 text-white p-4">
                    <h3 className="font-bold text-xl">Medium Loans</h3>
                    <p className="opacity-80">For growing businesses</p>
                  </div>
                  <div className="p-6">
                    <div className="flex justify-between mb-3 pb-3 border-b">
                      <span className="text-gray-600">Starting amount:</span>
                      <span className="font-semibold">50,000 BDT</span>
                    </div>
                    <div className="flex justify-between mb-3 pb-3 border-b">
                      <span className="text-gray-600">Maximum amount:</span>
                      <span className="font-semibold">100,000 BDT</span>
                    </div>
                    <div className="flex justify-between mb-3 pb-3 border-b">
                      <span className="text-gray-600">Term:</span>
                      <span className="font-semibold">1 year</span>
                    </div>
                    <div className="flex items-center justify-center mt-6">
                      <Calendar className="text-blue-600 mr-2" size={18} />
                      <span className="text-gray-700">Structured repayment plans</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="mt-8 bg-blue-50 p-6 rounded-lg border border-blue-100">
                <h4 className="font-bold text-blue-900 mb-2">Our Commitment</h4>
                <p className="text-gray-700">
                  We believe in providing more than just financial support. Our loans come with guidance and resources to help you maximize the impact of your funds and achieve sustainable growth.
                </p>
              </div>
            </div>
          </div>
        </section>
        
        {/* Call to Action */}
        <section>
          <div className="bg-gradient-to-r from-blue-900 to-blue-700 text-white rounded-lg shadow-lg p-8 text-center animate-fade-in">
            <h2 className="text-2xl md:text-3xl font-bold mb-4">Ready to Start Your Journey?</h2>
            <p className="mb-6 max-w-2xl mx-auto">
              Contact us today to learn more about our services and how we can help you achieve your financial goals.
            </p>
            <button className="bg-white text-blue-900 font-semibold py-3 px-8 rounded-full hover:bg-blue-50 transition-colors duration-300">
              Contact Us
            </button>
          </div>
        </section>
      </div>
    </div>
  );
};

export default AboutUs;